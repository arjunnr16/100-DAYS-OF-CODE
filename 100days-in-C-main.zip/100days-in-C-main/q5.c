 // Write a program to convert temperature from Celsius to Fahrenheit.
#include <stdio.h>
int main(){
    float a,c;
    printf("Write Celsius");
    scanf("%f",&a);
    c = (a*9/5) + 32;
    printf("fahrenheit");
    printf("%f",c);
    return 0;
}
