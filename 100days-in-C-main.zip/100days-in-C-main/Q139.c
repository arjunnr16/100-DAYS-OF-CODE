#include <stdio.h>
enum ex{X,Y,Z};
int main(){ printf("%d %d %d",X,Y,Z);}