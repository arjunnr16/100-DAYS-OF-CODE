// Write a program to swap two numbers using a third variable.
# include <stdio.h>
int main(){
    int a,b,c;
    printf("Write two number : ");
    scanf("%d %d",&a,&b);
    c = b;
    b = a;
    a = c;
    printf("number after swap:");
    printf("%d %d",a,b);
    return 0;
}
