#include <stdio.h>
enum test{A=10,B,C,D};
int main(){ printf("%d %d %d %d",A,B,C,D);}