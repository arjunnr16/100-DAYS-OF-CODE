// Write a program to input two numbers and display their sum.
