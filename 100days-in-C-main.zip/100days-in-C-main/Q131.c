#include <stdio.h>
enum days{SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY};
int main(){ for(int d=SUNDAY; d<=SATURDAY; d++) printf("%d\n",d);}