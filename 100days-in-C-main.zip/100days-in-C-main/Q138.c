#include <stdio.h>
enum x{A1,B1,C1};
int main(){ for(int i=A1;i<=C1;i++) printf("%d ",i);}